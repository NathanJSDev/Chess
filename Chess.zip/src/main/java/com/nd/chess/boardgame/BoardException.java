package com.nd.chess.boardgame;

public class BoardException extends RuntimeException {
    private static final long serialVersionUID = 1l;

    public BoardException(String msg){
        super(msg);
    }
    
}
