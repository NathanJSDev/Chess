package com.nd.chess.chess;

public enum Color {
    BLACK,WHITE;
}
